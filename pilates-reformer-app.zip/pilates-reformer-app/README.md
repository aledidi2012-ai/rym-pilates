# Estudio Equilibrio — app de reservas (Reformer)

App para reservar clases de pilates reformer, con panel admin para gestionar
clases, alumnos y planes mensuales. Hecha con Expo (React Native) + Supabase.

## Qué incluye

- **Pantalla Cliente**: ver clases por día, reservar, cancelar, ver cupos,
  confirmar por WhatsApp o mail.
- **Pantalla Admin** (con PIN): crear/eliminar clases, ver quién reservó cada
  una, gestionar alumnos (plan mensual de clases, marcar pagado/pendiente).

## Antes de arrancar

Necesitás tener instalado:
- [Node.js](https://nodejs.org) (versión 18 o superior)
- La app **Expo Go** en tu celular (para probar sin compilar nada) — buscala
  en App Store o Play Store.

## 1. Crear el backend (Supabase, gratis)

1. Entrá a [supabase.com](https://supabase.com) y creá una cuenta y un proyecto nuevo.
2. Andá a **SQL Editor > New query**, pegá todo el contenido de
   `supabase-schema.sql` (incluido en esta carpeta) y hacé clic en **Run**.
   Esto crea las tablas de clases, alumnos, reservas y configuración, con
   4 clases de ejemplo.
3. Andá a **Project Settings > API** y copiá:
   - **Project URL**
   - **anon public key**
4. Abrí `src/lib/supabase.js` y pegá esos dos valores donde dice
   `TU_SUPABASE_URL` y `TU_SUPABASE_ANON_KEY`.

## 2. Correr la app en tu celular

```bash
npm install
npx expo start
```

Esto abre una pantalla con un código QR. Escaneálo con la cámara del celu
(iPhone) o desde la app Expo Go (Android) y la app se abre ahí, conectada a
tu Supabase real. El PIN de admin por defecto es `1234` (lo podés cambiar
desde la app, en Admin > Ajustes).

## 3. Pendiente antes de publicar (importante)

Este es un primer desarrollo funcional, no todavía listo para tiendas.
Cosas a resolver antes de subirlo:

- **El registro de alumnos usa `Alert.prompt`, que solo funciona en iOS.**
  En Android no pide los datos. Hay que reemplazar `askText()` en
  `ClientScreen.js` y `AdminScreen.js` por un modal propio con `<TextInput>`
  que funcione en ambos sistemas — es un cambio acotado, pero hay que
  hacerlo antes de probar en Android.
- **Seguridad de datos**: el esquema SQL deja la base abierta con la `anon
  key` para que todo funcione rápido de entrada. Antes de lanzarla con
  alumnos reales, conviene sumar Supabase Auth (login real) y políticas RLS
  más estrictas — hoy cualquiera con la app podría, en teoría, leer o tocar
  los datos de otros alumnos.
- **Ícono y splash screen**: hoy usa colores planos. Sumá tu logo real en
  `app.json` (`icon`, `splash.image`).
- **Nombres de paquete**: cambiá `com.tuestudio.equilibrio` en `app.json`
  por el identificador real de tu estudio antes de publicar.
- Los links de WhatsApp/mail abren la app de WhatsApp o Mail del alumno con
  el mensaje ya escrito — el alumno tiene que tocar "enviar". No son
  notificaciones automáticas (eso requeriría un servicio adicional, como
  push notifications o la API de WhatsApp Business).

## 4. Publicar en App Store y Play Store

Cuando esté lista, se usa **EAS** (el servicio de build de Expo):

```bash
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android
eas build --platform ios
```

- Para Android: necesitás una cuenta de **Google Play Console** (pago único
  de USD 25).
- Para iOS: necesitás una cuenta de **Apple Developer Program** (USD 99/año).

Con el build listo, `eas submit` lo sube directo a cada tienda. La guía
oficial y actualizada está en https://docs.expo.dev/submit/introduction/.
