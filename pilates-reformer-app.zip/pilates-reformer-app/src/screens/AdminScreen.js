import React, { useCallback, useEffect, useState } from "react";
import {
  View, Text, ScrollView, TouchableOpacity, TextInput,
  StyleSheet, Alert, Platform,
} from "react-native";
import { supabase } from "../lib/supabase";
import { colors, spacing, radius } from "../theme";

const DAYS = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];

function askText(title, message) {
  return new Promise((resolve) => {
    if (Platform.OS === "ios") {
      Alert.prompt(title, message, [
        { text: "Cancelar", style: "cancel", onPress: () => resolve(null) },
        { text: "Listo", onPress: (text) => resolve(text || "") },
      ]);
    } else {
      Alert.alert("Falta implementar en Android", "Reemplazá askText() por un modal con TextInput (ver README).");
      resolve(null);
    }
  });
}

export default function AdminScreen() {
  const [unlocked, setUnlocked] = useState(false);
  const [pinInput, setPinInput] = useState("");
  const [adminPin, setAdminPin] = useState("1234");

  const [classes, setClasses] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [students, setStudents] = useState([]);

  const [newClass, setNewClass] = useState({ day: "Lun", time: "09:00", name: "", instructor: "", capacity: "6" });

  const loadAll = useCallback(async () => {
    const [{ data: cls }, { data: bks }, { data: studs }, { data: settings }] = await Promise.all([
      supabase.from("classes").select("*"),
      supabase.from("bookings").select("*"),
      supabase.from("students").select("*"),
      supabase.from("settings").select("*").eq("id", 1).single(),
    ]);
    setClasses(cls || []);
    setBookings(bks || []);
    setStudents(studs || []);
    if (settings?.admin_pin) setAdminPin(settings.admin_pin);
  }, []);

  useEffect(() => { if (unlocked) loadAll(); }, [unlocked, loadAll]);

  function tryUnlock() {
    if (pinInput === adminPin) { setUnlocked(true); return; }
    // primer uso: la tabla settings trae el PIN por defecto '1234' desde el schema
    Alert.alert("PIN incorrecto");
  }

  async function addClass() {
    if (!newClass.name || !newClass.instructor || !newClass.time) {
      Alert.alert("Faltan datos", "Completá todos los campos.");
      return;
    }
    await supabase.from("classes").insert({
      day: newClass.day, time: newClass.time, name: newClass.name,
      instructor: newClass.instructor, capacity: parseInt(newClass.capacity, 10) || 1,
    });
    setNewClass({ day: "Lun", time: "09:00", name: "", instructor: "", capacity: "6" });
    loadAll();
  }

  async function deleteClass(id) {
    Alert.alert("Eliminar clase", "¿Eliminar esta clase y sus reservas?", [
      { text: "Cancelar", style: "cancel" },
      { text: "Eliminar", style: "destructive", onPress: async () => {
          await supabase.from("bookings").delete().eq("class_id", id);
          await supabase.from("classes").delete().eq("id", id);
          loadAll();
        } },
    ]);
  }

  async function removeBooking(booking) {
    const s = students.find((x) => x.id === booking.student_id);
    await supabase.from("bookings").delete().eq("id", booking.id);
    if (s) await supabase.from("students").update({ used: Math.max(0, s.used - 1) }).eq("id", s.id);
    loadAll();
  }

  async function togglePaid(s) {
    const paid = !s.paid;
    const patch = paid
      ? { paid: true, used: 0, month_key: `${new Date().getFullYear()}-${new Date().getMonth() + 1}` }
      : { paid: false };
    await supabase.from("students").update(patch).eq("id", s.id);
    loadAll();
  }

  async function updatePlan(s, value) {
    const n = Math.max(1, parseInt(value, 10) || 1);
    await supabase.from("students").update({ classes_per_month: n }).eq("id", s.id);
  }

  async function deleteStudent(s) {
    Alert.alert("Eliminar alumno", `¿Eliminar a ${s.name} y sus reservas?`, [
      { text: "Cancelar", style: "cancel" },
      { text: "Eliminar", style: "destructive", onPress: async () => {
          await supabase.from("bookings").delete().eq("student_id", s.id);
          await supabase.from("students").delete().eq("id", s.id);
          loadAll();
        } },
    ]);
  }

  async function changePin() {
    const cur = await askText("PIN actual", "");
    if (cur !== adminPin) { Alert.alert("PIN actual incorrecto"); return; }
    const next = await askText("Nuevo PIN", "");
    if (!next) return;
    await supabase.from("settings").update({ admin_pin: next }).eq("id", 1);
    setAdminPin(next);
    Alert.alert("PIN actualizado");
  }

  if (!unlocked) {
    return (
      <View style={styles.pinScreen}>
        <Text style={styles.pinTitle}>Acceso administrador</Text>
        <Text style={styles.pinSubtitle}>Ingresá el PIN para gestionar clases, alumnos y pagos.</Text>
        <TextInput
          style={styles.pinInput}
          value={pinInput}
          onChangeText={setPinInput}
          keyboardType="number-pad"
          secureTextEntry
          maxLength={8}
          placeholder="PIN"
        />
        <TouchableOpacity style={styles.btnPrimaryWide} onPress={tryUnlock}>
          <Text style={styles.btnPrimaryText}>Ingresar</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const sortedClasses = [...classes].sort(
    (a, b) => DAYS.indexOf(a.day) - DAYS.indexOf(b.day) || a.time.localeCompare(b.time)
  );

  return (
    <ScrollView style={styles.root}>
      <View style={styles.header}>
        <Text style={styles.h1}>Panel admin</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Nueva clase</Text>
        <View style={styles.card}>
          <View style={styles.dayPicker}>
            {DAYS.map((d) => (
              <TouchableOpacity
                key={d}
                style={[styles.dayChip, newClass.day === d && styles.dayChipActive]}
                onPress={() => setNewClass({ ...newClass, day: d })}
              >
                <Text style={[styles.dayChipText, newClass.day === d && styles.dayChipTextActive]}>{d}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <TextInput style={styles.input} placeholder="Hora (ej: 09:00)" value={newClass.time}
            onChangeText={(t) => setNewClass({ ...newClass, time: t })} />
          <TextInput style={styles.input} placeholder="Nombre de la clase (ej: Reformer Nivel 1)" value={newClass.name}
            onChangeText={(t) => setNewClass({ ...newClass, name: t })} />
          <TextInput style={styles.input} placeholder="Profe" value={newClass.instructor}
            onChangeText={(t) => setNewClass({ ...newClass, instructor: t })} />
          <TextInput style={styles.input} placeholder="Cupo" keyboardType="number-pad" value={newClass.capacity}
            onChangeText={(t) => setNewClass({ ...newClass, capacity: t })} />
          <TouchableOpacity style={styles.btnPrimaryWide} onPress={addClass}>
            <Text style={styles.btnPrimaryText}>Agregar clase</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Clases y reservas</Text>
        {sortedClasses.length === 0 && <Text style={styles.empty}>Todavía no cargaste clases.</Text>}
        {sortedClasses.map((c) => {
          const bks = bookings.filter((b) => b.class_id === c.id);
          return (
            <View key={c.id} style={styles.card}>
              <View style={styles.cardTopRow}>
                <View>
                  <Text style={styles.classTime}>{c.day} · {c.time}</Text>
                  <Text style={styles.classMeta}>{c.name} — {c.instructor} · {bks.length}/{c.capacity} cupos</Text>
                </View>
                <TouchableOpacity style={styles.btnGhost} onPress={() => deleteClass(c.id)}>
                  <Text style={styles.btnGhostText}>Eliminar</Text>
                </TouchableOpacity>
              </View>
              {bks.length === 0 ? (
                <Text style={styles.bookingRowEmpty}>Sin reservas todavía</Text>
              ) : (
                bks.map((b) => {
                  const s = students.find((x) => x.id === b.student_id);
                  return (
                    <View key={b.id} style={styles.bookingRow}>
                      <Text style={styles.bookingName}>{s ? s.name : "Alumno"}</Text>
                      <TouchableOpacity onPress={() => removeBooking(b)}>
                        <Text style={styles.linkDanger}>quitar</Text>
                      </TouchableOpacity>
                    </View>
                  );
                })
              )}
            </View>
          );
        })}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Alumnos y planes</Text>
        {students.length === 0 && <Text style={styles.empty}>Todavía no hay alumnos registrados.</Text>}
        {students.map((s) => (
          <View key={s.id} style={styles.card}>
            <View style={styles.cardTopRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.studentName}>{s.name}</Text>
                <Text style={styles.classMeta}>{s.phone || "sin teléfono"}{s.email ? ` · ${s.email}` : ""}</Text>
                <View style={styles.planRow}>
                  <Text style={styles.classMeta}>Plan: </Text>
                  <TextInput
                    style={styles.planInput}
                    keyboardType="number-pad"
                    defaultValue={String(s.classes_per_month)}
                    onEndEditing={(e) => updatePlan(s, e.nativeEvent.text)}
                  />
                  <Text style={styles.classMeta}> clases/mes · usó {s.used}</Text>
                </View>
              </View>
              <TouchableOpacity
                style={[styles.pillToggle, s.paid ? styles.pillPaid : styles.pillDue]}
                onPress={() => togglePaid(s)}
              >
                <Text style={[styles.pillToggleText, s.paid ? styles.pillPaidText : styles.pillDueText]}>
                  {s.paid ? "Al día" : "Pago pendiente"}
                </Text>
              </TouchableOpacity>
            </View>
            <TouchableOpacity onPress={() => deleteStudent(s)} style={{ alignSelf: "flex-end", marginTop: 8 }}>
              <Text style={styles.linkDanger}>eliminar alumno</Text>
            </TouchableOpacity>
          </View>
        ))}
      </View>

      <View style={[styles.section, { marginBottom: 60 }]}>
        <Text style={styles.sectionTitle}>Ajustes</Text>
        <View style={[styles.card, styles.cardTopRow]}>
          <Text style={styles.classMeta}>PIN de acceso admin</Text>
          <TouchableOpacity style={styles.btnGhost} onPress={changePin}>
            <Text style={styles.btnGhostText}>Cambiar PIN</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  header: { padding: spacing.xl, paddingBottom: spacing.sm },
  h1: { fontSize: 24, fontWeight: "700", color: colors.ink },
  section: { paddingHorizontal: spacing.xl },
  sectionTitle: { fontSize: 17, fontWeight: "700", color: colors.ink, marginVertical: spacing.md },
  card: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.line, borderRadius: radius.lg, padding: spacing.lg, marginBottom: spacing.md },
  cardTopRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  input: { borderWidth: 1, borderColor: colors.line, backgroundColor: colors.surface, borderRadius: radius.sm, padding: 10, marginBottom: 8, fontSize: 14 },
  dayPicker: { flexDirection: "row", flexWrap: "wrap", gap: 6, marginBottom: 8 },
  dayChip: { borderWidth: 1, borderColor: colors.line, backgroundColor: colors.surface2, paddingVertical: 6, paddingHorizontal: 12, borderRadius: radius.pill },
  dayChipActive: { backgroundColor: colors.sage, borderColor: colors.sage },
  dayChipText: { color: colors.inkSoft, fontWeight: "600", fontSize: 12 },
  dayChipTextActive: { color: colors.white },
  btnPrimaryWide: { backgroundColor: colors.sage, paddingVertical: 12, borderRadius: radius.sm, alignItems: "center", marginTop: 4 },
  btnPrimaryText: { color: colors.white, fontWeight: "700" },
  btnGhost: { backgroundColor: colors.surface2, paddingVertical: 8, paddingHorizontal: 12, borderRadius: radius.sm },
  btnGhostText: { color: colors.ink, fontWeight: "600", fontSize: 13 },
  classTime: { fontSize: 16, fontWeight: "700", color: colors.sageDark },
  classMeta: { fontSize: 13, color: colors.inkSoft },
  bookingRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 6, borderTopWidth: 1, borderTopColor: colors.line, marginTop: 6 },
  bookingRowEmpty: { fontSize: 13, color: colors.inkSoft, paddingTop: 8, borderTopWidth: 1, borderTopColor: colors.line, marginTop: 8 },
  bookingName: { fontSize: 13.5, color: colors.ink },
  linkDanger: { color: colors.danger, fontSize: 12.5, fontWeight: "600" },
  studentName: { fontSize: 15, fontWeight: "700", color: colors.ink },
  planRow: { flexDirection: "row", alignItems: "center", marginTop: 4, flexWrap: "wrap" },
  planInput: { borderWidth: 1, borderColor: colors.line, borderRadius: 6, width: 44, textAlign: "center", paddingVertical: 2 },
  pillToggle: { paddingVertical: 6, paddingHorizontal: 10, borderRadius: radius.pill },
  pillPaid: { backgroundColor: "#E1E9D8" },
  pillDue: { backgroundColor: colors.dangerSoft },
  pillToggleText: { fontSize: 12, fontWeight: "600" },
  pillPaidText: { color: colors.sageDark },
  pillDueText: { color: colors.danger },
  pinScreen: { flex: 1, backgroundColor: colors.bg, alignItems: "center", justifyContent: "center", padding: 30 },
  pinTitle: { fontSize: 20, fontWeight: "700", color: colors.ink, marginBottom: 6 },
  pinSubtitle: { fontSize: 13.5, color: colors.inkSoft, textAlign: "center", marginBottom: 18 },
  pinInput: { borderWidth: 1, borderColor: colors.line, backgroundColor: colors.surface, borderRadius: radius.sm, padding: 12, width: 160, textAlign: "center", fontSize: 18, letterSpacing: 4, marginBottom: 14 },
});
