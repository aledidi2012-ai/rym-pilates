import React, { useCallback, useEffect, useState } from "react";
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  Linking, Alert, Platform, RefreshControl,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { supabase } from "../lib/supabase";
import { colors, spacing, radius } from "../theme";

const DAYS = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];

function currentMonthKey() {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}`;
}

// IMPORTANTE: Alert.prompt solo existe en iOS. Esta función funciona para probar
// rápido en iOS/Expo Go, pero en Android no pedirá texto (ver nota en README):
// antes de publicar reemplazá esto por un modal propio con <TextInput>.
function askText(title, message) {
  return new Promise((resolve) => {
    if (Platform.OS === "ios") {
      Alert.prompt(title, message, [
        { text: "Cancelar", style: "cancel", onPress: () => resolve(null) },
        { text: "Listo", onPress: (text) => resolve(text || "") },
      ]);
    } else {
      Alert.alert(
        "Falta implementar en Android",
        "Reemplazá askText() por un modal con TextInput antes de probar en Android (ver README)."
      );
      resolve(null);
    }
  });
}

export default function ClientScreen() {
  const [classes, setClasses] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [myStudent, setMyStudent] = useState(null);
  const [selectedDay, setSelectedDay] = useState("Lun");
  const [refreshing, setRefreshing] = useState(false);

  const loadAll = useCallback(async () => {
    const [{ data: cls }, { data: bks }] = await Promise.all([
      supabase.from("classes").select("*"),
      supabase.from("bookings").select("*"),
    ]);
    setClasses(cls || []);
    setBookings(bks || []);

    const myId = await AsyncStorage.getItem("my-student-id");
    if (myId) {
      const { data: s } = await supabase.from("students").select("*").eq("id", myId).single();
      if (s) {
        if (s.month_key !== currentMonthKey()) {
          const { data: updated } = await supabase
            .from("students")
            .update({ used: 0, paid: false, month_key: currentMonthKey() })
            .eq("id", s.id)
            .select()
            .single();
          setMyStudent(updated);
        } else {
          setMyStudent(s);
        }
      }
    }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadAll();
    setRefreshing(false);
  };

  const spotsTaken = (classId) => bookings.filter((b) => b.class_id === classId).length;
  const isBookedByMe = (classId) =>
    myStudent && bookings.some((b) => b.class_id === classId && b.student_id === myStudent.id);

  async function registerStudent() {
    // Ver README: reemplazar estos Alert.prompt (solo iOS) por un modal con TextInput
    // que funcione igual en Android antes de publicar.
    const name = await askText("¿Cómo te llamás?", "");
    if (!name) return null;
    const phone = await askText("Tu WhatsApp (con código de país)", "Ej: 5491122334455");
    const email = await askText("Tu email (opcional)", "");
    const { data, error } = await supabase
      .from("students")
      .insert({
        name, phone: phone || "", email: email || "",
        classes_per_month: 4, used: 0, paid: true, month_key: currentMonthKey(),
      })
      .select()
      .single();
    if (error) { Alert.alert("Error", "No se pudo registrar. Probá de nuevo."); return null; }
    await AsyncStorage.setItem("my-student-id", data.id);
    setMyStudent(data);
    return data;
  }

  async function bookClass(cls) {
    let s = myStudent;
    if (!s) s = await registerStudent();
    if (!s) return;

    if (!s.paid) { Alert.alert("Cuota pendiente", "Contactá al estudio para reactivar tu plan."); return; }
    if (s.used >= s.classes_per_month) { Alert.alert("Límite alcanzado", "Ya usaste las clases de tu plan este mes."); return; }
    if (spotsTaken(cls.id) >= cls.capacity) { Alert.alert("Sin cupo", "Esa clase ya está completa."); return; }
    if (isBookedByMe(cls.id)) { Alert.alert("Ya reservada", "Ya tenés un lugar en esa clase."); return; }

    const { error: bErr } = await supabase.from("bookings").insert({ class_id: cls.id, student_id: s.id });
    if (bErr) { Alert.alert("Error", "No se pudo reservar."); return; }
    await supabase.from("students").update({ used: s.used + 1 }).eq("id", s.id);
    await loadAll();
  }

  async function cancelBooking(cls) {
    if (!myStudent) return;
    const b = bookings.find((x) => x.class_id === cls.id && x.student_id === myStudent.id);
    if (!b) return;
    await supabase.from("bookings").delete().eq("id", b.id);
    await supabase.from("students").update({ used: Math.max(0, myStudent.used - 1) }).eq("id", myStudent.id);
    await loadAll();
  }

  function confirmWhatsapp(cls) {
    if (!myStudent?.phone) return;
    const text = `Hola! Confirmo mi reserva en Estudio Equilibrio: ${cls.name} el ${cls.day} ${cls.time} hs.`;
    Linking.openURL(`https://wa.me/${myStudent.phone.replace(/[^0-9]/g, "")}?text=${encodeURIComponent(text)}`);
  }
  function confirmMail(cls) {
    if (!myStudent?.email) return;
    const text = `Hola! Confirmo mi reserva en Estudio Equilibrio: ${cls.name} el ${cls.day} ${cls.time} hs.`;
    Linking.openURL(`mailto:${myStudent.email}?subject=${encodeURIComponent("Confirmación de reserva")}&body=${encodeURIComponent(text)}`);
  }

  const dayClasses = classes
    .filter((c) => c.day === selectedDay)
    .sort((a, b) => a.time.localeCompare(b.time));

  return (
    <ScrollView
      style={styles.root}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
    >
      <View style={styles.header}>
        <Text style={styles.eyebrow}>Estudio Equilibrio</Text>
        <Text style={styles.h1}>Reservá tu clase</Text>
      </View>

      {myStudent && (
        <View style={styles.nameBanner}>
          <Text style={styles.nameBannerText}>
            Reservando como <Text style={{ fontWeight: "700" }}>{myStudent.name}</Text> ·{" "}
            {myStudent.used}/{myStudent.classes_per_month} clases este mes
          </Text>
        </View>
      )}

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.daybar}>
        {DAYS.map((d) => (
          <TouchableOpacity
            key={d}
            style={[styles.dayChip, selectedDay === d && styles.dayChipActive]}
            onPress={() => setSelectedDay(d)}
          >
            <Text style={[styles.dayChipText, selectedDay === d && styles.dayChipTextActive]}>{d}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <View style={styles.content}>
        {dayClasses.length === 0 && <Text style={styles.empty}>No hay clases este día.</Text>}

        {dayClasses.map((c) => {
          const taken = spotsTaken(c.id);
          const full = taken >= c.capacity;
          const mine = isBookedByMe(c.id);
          return (
            <View key={c.id} style={styles.card}>
              <View style={styles.cardTop}>
                <View>
                  <Text style={styles.classTime}>{c.time}</Text>
                  <Text style={styles.className}>{c.name}</Text>
                  <Text style={styles.classMeta}>con {c.instructor}</Text>
                </View>
                <View style={[styles.spots, full && styles.spotsFull]}>
                  <Text style={[styles.spotsText, full && styles.spotsTextFull]}>
                    {taken}/{c.capacity} lugares
                  </Text>
                </View>
              </View>

              <View style={styles.rowActions}>
                {mine ? (
                  <>
                    <TouchableOpacity style={styles.btnDanger} onPress={() => cancelBooking(c)}>
                      <Text style={styles.btnDangerText}>Cancelar reserva</Text>
                    </TouchableOpacity>
                    {myStudent?.phone ? (
                      <TouchableOpacity style={styles.btnWa} onPress={() => confirmWhatsapp(c)}>
                        <Text style={styles.btnWaText}>WhatsApp</Text>
                      </TouchableOpacity>
                    ) : null}
                    {myStudent?.email ? (
                      <TouchableOpacity style={styles.btnGhost} onPress={() => confirmMail(c)}>
                        <Text style={styles.btnGhostText}>Mail</Text>
                      </TouchableOpacity>
                    ) : null}
                  </>
                ) : (
                  <TouchableOpacity
                    style={[styles.btnPrimary, full && styles.btnDisabled]}
                    disabled={full}
                    onPress={() => bookClass(c)}
                  >
                    <Text style={styles.btnPrimaryText}>{full ? "Sin cupo" : "Reservar"}</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          );
        })}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  header: { padding: spacing.xl, paddingBottom: spacing.md },
  eyebrow: { color: colors.sageDark, fontWeight: "600", fontSize: 13 },
  h1: { fontSize: 26, fontWeight: "700", color: colors.ink, marginTop: 2 },
  nameBanner: { backgroundColor: colors.surface2, marginHorizontal: spacing.xl, padding: spacing.md, borderRadius: radius.md, marginBottom: spacing.sm },
  nameBannerText: { color: colors.inkSoft, fontSize: 13 },
  daybar: { paddingHorizontal: spacing.xl, marginBottom: spacing.sm },
  dayChip: { borderWidth: 1, borderColor: colors.line, backgroundColor: colors.surface, paddingVertical: 8, paddingHorizontal: 16, borderRadius: radius.pill, marginRight: 6 },
  dayChipActive: { backgroundColor: colors.sage, borderColor: colors.sage },
  dayChipText: { color: colors.inkSoft, fontWeight: "600", fontSize: 13 },
  dayChipTextActive: { color: colors.white },
  content: { paddingHorizontal: spacing.xl, paddingBottom: 80 },
  empty: { textAlign: "center", color: colors.inkSoft, paddingVertical: 40 },
  card: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.line, borderRadius: radius.lg, padding: spacing.lg, marginBottom: spacing.md },
  cardTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  classTime: { fontSize: 20, fontWeight: "700", color: colors.sageDark },
  className: { fontSize: 16, fontWeight: "700", color: colors.ink, marginTop: 2 },
  classMeta: { fontSize: 13, color: colors.inkSoft },
  spots: { backgroundColor: colors.claySoft, borderRadius: radius.pill, paddingHorizontal: 10, paddingVertical: 4 },
  spotsFull: { backgroundColor: colors.dangerSoft },
  spotsText: { color: colors.clay, fontSize: 12, fontWeight: "600" },
  spotsTextFull: { color: colors.danger },
  rowActions: { flexDirection: "row", gap: 8, marginTop: spacing.md, flexWrap: "wrap" },
  btnPrimary: { backgroundColor: colors.sage, flex: 1, paddingVertical: 10, borderRadius: radius.sm, alignItems: "center" },
  btnDisabled: { backgroundColor: colors.line },
  btnPrimaryText: { color: colors.white, fontWeight: "600" },
  btnDanger: { backgroundColor: colors.surface2, flex: 1, paddingVertical: 10, borderRadius: radius.sm, alignItems: "center" },
  btnDangerText: { color: colors.danger, fontWeight: "600" },
  btnWa: { backgroundColor: colors.whatsapp, paddingVertical: 10, paddingHorizontal: 14, borderRadius: radius.sm, alignItems: "center" },
  btnWaText: { color: colors.white, fontWeight: "600", fontSize: 13 },
  btnGhost: { backgroundColor: colors.surface2, paddingVertical: 10, paddingHorizontal: 14, borderRadius: radius.sm, alignItems: "center" },
  btnGhostText: { color: colors.ink, fontWeight: "600", fontSize: 13 },
});
