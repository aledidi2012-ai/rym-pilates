export const colors = {
  bg: "#EDEAE1",
  surface: "#FBFAF7",
  surface2: "#F2EEE4",
  ink: "#2A2A24",
  inkSoft: "#6B6A5F",
  line: "#DCD6C6",
  sage: "#67754E",
  sageDark: "#4D5A38",
  clay: "#A96E4E",
  claySoft: "#EFDFCF",
  danger: "#A64B3D",
  dangerSoft: "#F1DEDA",
  whatsapp: "#4A7A5E",
  white: "#FFFFFF",
};

export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24 };
export const radius = { sm: 8, md: 12, lg: 16, pill: 999 };
