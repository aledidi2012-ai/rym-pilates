-- Ejecutá esto en Supabase: proyecto > SQL Editor > New query > Run

create extension if not exists "pgcrypto";

create table classes (
  id uuid primary key default gen_random_uuid(),
  day text not null,
  time text not null,
  name text not null,
  instructor text not null,
  capacity int not null default 6
);

create table students (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  email text,
  classes_per_month int not null default 4,
  used int not null default 0,
  paid boolean not null default true,
  month_key text not null
);

create table bookings (
  id uuid primary key default gen_random_uuid(),
  class_id uuid references classes(id) on delete cascade,
  student_id uuid references students(id) on delete cascade,
  created_at timestamptz default now()
);

create table settings (
  id int primary key default 1,
  admin_pin text not null default '1234'
);
insert into settings (id, admin_pin) values (1, '1234');

-- Datos de ejemplo (opcional, podés borrarlos desde el panel admin)
insert into classes (day, time, name, instructor, capacity) values
  ('Lun', '08:00', 'Reformer Nivel 1', 'Sofía', 6),
  ('Lun', '18:00', 'Reformer Nivel 2', 'Male', 6),
  ('Mié', '09:00', 'Reformer Nivel 1', 'Sofía', 6),
  ('Vie', '19:00', 'Reformer Flow', 'Male', 6);

-- MVP: acceso abierto con la anon key (sin login de usuarios todavía).
-- Antes de lanzar de verdad, restringí esto con Supabase Auth + políticas RLS reales.
alter table classes enable row level security;
alter table students enable row level security;
alter table bookings enable row level security;
alter table settings enable row level security;

create policy "anon full access classes" on classes for all using (true) with check (true);
create policy "anon full access students" on students for all using (true) with check (true);
create policy "anon full access bookings" on bookings for all using (true) with check (true);
create policy "anon full access settings" on settings for all using (true) with check (true);
